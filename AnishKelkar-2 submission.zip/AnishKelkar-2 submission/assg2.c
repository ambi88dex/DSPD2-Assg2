// treap == tree + min-heap
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
typedef struct node
{
    int key;
    struct node* left, *right;
    float priority;
} node;
node* createNode(int key, float prior )
{
    node* temp=(node*)malloc(sizeof(node));
    temp->key=key;
    temp->priority=prior;
    temp->right=NULL;
    temp->left=NULL;
    return temp;
}
node* rotateRight(node* root)
{
    node* temp=root->left;
    root->left=temp->right;
    temp->right=root;
    return temp;
}
node* rotateLeft(node *root)
{
    node* temp=root->right;
    root->right=temp->left;
    temp->left=root;
    return temp;
}
node* treapInsert(node* root, int key, float prior)
{
    //node* ret;
    if(root==NULL)
    {
        root=createNode(key,prior);
        //ret=root;
    }
    else
    {
        if(root->key>key)
        {
            root->left=treapInsert(root->left,key,prior);
            if(root->priority>root->left->priority)
            {
                root=rotateRight(root);
            }
        }
        else
        {
            root->right=treapInsert(root->right,key,prior);
            if(root->priority>root->right->priority)
            {
                root=rotateLeft(root);
            }
        }
    }
    return root;
}
node* removeNode(node* root)
{
    node* create;
    if(root!=NULL)
    {
        if(root->left!=NULL)
        {
            if(root->right!=NULL)
            {
                if(root->left->priority>root->right->priority)
                {
                    root=rotateLeft(root);
                    root->left=removeNode(root->left);
                }
                else
                {
                    root=rotateRight(root);
                    root->right=removeNode(root->right);
                }
            }
            else
            {
                create=root->left;
                free(root);
                root=create;
            }
        }
        else
        {
            if(root->right!=NULL)
            {
                create=root->right;
                free(root);
                root=root->right;
            }
            else
            {
                free(root);
                root=NULL;
            }
        }
    }
    return root;
}
node* treapDelete(node* root , int key, int* deleteDone)
{
    if(root!=NULL)
    {
        if(root->key==key)
        {
            *deleteDone=1;
            root=removeNode(root);
        }
        else
        {
            if(*deleteDone==0)
            {
                if(root->left!=NULL)
                {
                    root->left=treapDelete(root->left,key,deleteDone);
                }
            }
            if(*deleteDone==0)
            {
                if(root->right!=NULL)
                {
                    root->right=treapDelete(root->right,key,deleteDone);
                }
            }
        }
    }
    return root;
}
void inOrderTraversal(FILE *f2,node* root)
{
    if(root!=NULL)
    {
        inOrderTraversal(f2,root->left);
        fprintf(f2,"%d ",root->key);
        inOrderTraversal(f2,root->right);
    }
}
int main()
{
    FILE* f1;
    f1=fopen("input.txt","r");
    FILE *f2;
    f2=fopen("output.txt","w");
    node* root=NULL;
    int i;
    float rndNum;
    int key;
    int deleteDone=0;
    //printf("To insert press 1 ,to remove press 2 , to exit press 0\n");
    fprintf(f2, "Operation,key --> InOrderTraversal\n");
    int operation;
    fscanf(f1,"%d",&operation);
    while(operation!=0)
    {
        if(operation==1)
        {
            rndNum= rand();
            fscanf(f1,"%d",&key);
            root=treapInsert(root,key,rndNum);
        }
        else if(operation==2)
        {
            deleteDone=0;
            fscanf(f1,"%d",&key);
            root=treapDelete(root,key,&deleteDone);
        }
        fprintf(f2,"%d %d -->",operation,key);
        inOrderTraversal(f2,root);
        fprintf(f2,"\n");
        fscanf(f1,"%d",&operation);
    }
    return 0;
}
